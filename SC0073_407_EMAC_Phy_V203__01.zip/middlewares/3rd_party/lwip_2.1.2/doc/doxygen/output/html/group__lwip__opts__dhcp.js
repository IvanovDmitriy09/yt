var group__lwip__opts__dhcp =
[
    [ "DHCP_DOES_ARP_CHECK", "group__lwip__opts__dhcp.html#gab2d91de7b2fce879b0a213682e1b0b69", null ],
    [ "LWIP_DHCP", "group__lwip__opts__dhcp.html#ga8a6ec62dc121064ac591b1fd8567bee9", null ],
    [ "LWIP_DHCP_BOOTP_FILE", "group__lwip__opts__dhcp.html#ga3c2983cbd228011dd3e18cb417e7e423", null ],
    [ "LWIP_DHCP_GET_NTP_SRV", "group__lwip__opts__dhcp.html#ga2cc18315edcd5ffc083d1256f7d22a83", null ],
    [ "LWIP_DHCP_MAX_DNS_SERVERS", "group__lwip__opts__dhcp.html#ga60ccc20fbb08be24b5d5f599dd47a6a6", null ],
    [ "LWIP_DHCP_MAX_NTP_SERVERS", "group__lwip__opts__dhcp.html#ga9d014e3f7dc9e1e7c7decd8652ba65e2", null ]
];