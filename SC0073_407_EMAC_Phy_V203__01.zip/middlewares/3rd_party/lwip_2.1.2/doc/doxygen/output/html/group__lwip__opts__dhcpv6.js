var group__lwip__opts__dhcpv6 =
[
    [ "LWIP_DHCP6_GET_NTP_SRV", "group__lwip__opts__dhcpv6.html#ga5d08f76a7472daa7bcfe17343243bd77", null ],
    [ "LWIP_DHCP6_MAX_DNS_SERVERS", "group__lwip__opts__dhcpv6.html#ga92c3bc242ad20a5f398c45d332864a29", null ],
    [ "LWIP_DHCP6_MAX_NTP_SERVERS", "group__lwip__opts__dhcpv6.html#gaf3ac8e15d7a67429a02bc2317e16bcfe", null ],
    [ "LWIP_IPV6_DHCP6", "group__lwip__opts__dhcpv6.html#ga1ba67b6665026ec0c688dc4b0df047a6", null ],
    [ "LWIP_IPV6_DHCP6_STATEFUL", "group__lwip__opts__dhcpv6.html#ga3fc9dbe8feae61621cac4952ac28e155", null ],
    [ "LWIP_IPV6_DHCP6_STATELESS", "group__lwip__opts__dhcpv6.html#ga8d6bab14d580d2136430319aab6d7930", null ]
];