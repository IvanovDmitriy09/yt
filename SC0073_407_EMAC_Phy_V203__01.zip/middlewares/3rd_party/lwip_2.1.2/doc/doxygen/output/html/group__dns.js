var group__dns =
[
    [ "dns_gethostbyname", "group__dns.html#ga1e040ec38166dc9bfcc3473aab0c799f", null ],
    [ "dns_gethostbyname_addrtype", "group__dns.html#gae84449f60dca6b863142daca8e03ce79", null ],
    [ "dns_getserver", "group__dns.html#gad02111a6b26b93f1c3580d5f41a59af3", null ],
    [ "dns_setserver", "group__dns.html#gaf66c5d8273f83cdc2cdd8911fb68d584", null ]
];