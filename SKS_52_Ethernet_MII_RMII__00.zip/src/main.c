/**
  **************************************************************************
  * @file     main.c
  * @version  v2.0.0
  * @date     2020-11-02
  * @brief    main program
  **************************************************************************
*/

#include "SKS_52_board.h"
#include "at32f403a_407_clock.h"
#include "at32_emac.h"
#include "stdio.h"
#include "netconf.h"
#include "lwip/apps/httpd.h"

/** @addtogroup AT32F407_periph_examples
  * @{
  */
  
/** @addtogroup 407_EMAC_http_server EMAC_http_server
  * @{
  */

#define DELAY                            100
#define FAST                             1
#define SLOW                             4

uint8_t g_speed = FAST;
volatile uint32_t local_time = 0;
volatile uint8_t AddrPortEth = 0;

void adc_configuration(void);
void mx_rtc_clock_init(void);



/**
  * @brief  main function.
  * @param  none
  * @retval none
  */
int main(void)
{
  error_status status;      // Var: error_status status
  
  system_clock_config();    // BSP: at32f403a_407_clock.c

  mx_rtc_clock_init();


  at32_board_init();
  AddrPortEth = AddrPortEth_init();
  

  nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);

  delay_init();

  status = emac_system_init();

  while(status == ERROR);
  
  tcpip_stack_init();
  
  adc_configuration();
  httpd_init();
  
  for(;;)
  { 
    lwip_periodic_handle(local_time);
  }
}

/**
  * @brief  adc configuration
  * @param  none
  * @retval none
  */
void adc_configuration(void)
{
  gpio_init_type gpio_init_struct;
  adc_base_config_type adc_init_struct;
  
  crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_ADC1_PERIPH_CLOCK, TRUE);
  
  gpio_default_para_init(&gpio_init_struct);
  gpio_init_struct.gpio_mode = GPIO_MODE_ANALOG;
  gpio_init_struct.gpio_pins = GPIO_PINS_4;
  gpio_init(GPIOA, &gpio_init_struct);
  
  adc_combine_mode_select(ADC_INDEPENDENT_MODE);
  adc_init_struct.data_align = ADC_RIGHT_ALIGNMENT;
  adc_init_struct.ordinary_channel_length = 1;
  adc_init_struct.repeat_mode = TRUE;
  adc_init_struct.sequence_mode = FALSE;
  adc_base_config(ADC1, &adc_init_struct);
  adc_ordinary_channel_set(ADC1, ADC_CHANNEL_4, 1, ADC_SAMPLETIME_239_5);
  adc_ordinary_conversion_trigger_set(ADC1, ADC12_ORDINARY_TRIG_SOFTWARE, TRUE);
  
  adc_enable(ADC1, TRUE);  
  adc_calibration_init(ADC1);  
  while(adc_calibration_init_status_get(ADC1));
  adc_calibration_start(ADC1);
  while(adc_calibration_status_get(ADC1));
  
  adc_ordinary_software_trigger_enable(ADC1, TRUE);
}



/**
  * @brief  init rtc clock function
  * @param  none
  * @retval none
  */
void mx_rtc_clock_init(void)
{
  /* enable pwc periph clock */
  crm_periph_clock_enable(CRM_PWC_PERIPH_CLOCK, TRUE);
  /* enable battery powered domain access */
  pwc_battery_powered_domain_access(TRUE);

  if(CRM->bpdc_bit.rtcsel != CRM_RTC_CLOCK_LICK)
  {
    /* reset battery powered domain */
    crm_battery_powered_domain_reset(TRUE);
    crm_battery_powered_domain_reset(FALSE);

    /* config rtc clock source */
    crm_rtc_clock_select(CRM_RTC_CLOCK_LICK);
  }

  /* check lick enabled or not */
  if(crm_flag_get(CRM_LICK_STABLE_FLAG) == RESET)
  {
    crm_clock_source_enable(CRM_CLOCK_SOURCE_LICK, TRUE);
    while(crm_flag_get(CRM_LICK_STABLE_FLAG) == RESET);
  }
}



/**
  * @}
  */ 

/**
  * @}
  */ 
