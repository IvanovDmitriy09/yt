/**
  **************************************************************************
  * @file     readme.txt
  * @version  v2.0.0
  * @date     2020-11-02
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows the http server
  operating flow for at32f4xx series. for more detailed information, please
  refer to the application note document AN0053.
  
To connect the board "AT-START-407" V1.2 it is necessary to change the software:

---------------------------------------------------------------------------------
0. Config board 
at32_emac.h

//#define RX_REMAP                         (1)  // For Board "AT START F407" V1.2
#define RX_REMAP                         (0)    // For MSKS
#define CRYSTAL_ON_PHY                   (1)
//#define CRYSTAL_ON_PHY                   (0)    // Board "AT START F407" V1.2 without crystal on Phy

/* Select PHY MII or RMII Mode */
//#define MII_MODE 
#define RMII_MODE

/* DM9162 Support RMII and MII */
#define DM9162

/* DP83848 Support RMII and MII, RMII Must CLK_OUT 50MHz Clock */
//#define DP83848 


---------------------------------------------------------------------------------
1. Main.c. Add:
...

void adc_configuration(void);
void mx_rtc_clock_init(void);

...

int main(void)
{
  error_status status;
  
  system_clock_config();

  mx_rtc_clock_init();

...



/**
  * @brief  init rtc clock function
  * @param  none
  * @retval none
  */
void mx_rtc_clock_init(void)
{
  /* enable pwc periph clock */
  crm_periph_clock_enable(CRM_PWC_PERIPH_CLOCK, TRUE);
  /* enable battery powered domain access */
  pwc_battery_powered_domain_access(TRUE);

  if(CRM->bpdc_bit.rtcsel != CRM_RTC_CLOCK_LICK)
  {
    /* reset battery powered domain */
    crm_battery_powered_domain_reset(TRUE);
    crm_battery_powered_domain_reset(FALSE);

    /* config rtc clock source */
    crm_rtc_clock_select(CRM_RTC_CLOCK_LICK);
  }

  /* check lick enabled or not */
  if(crm_flag_get(CRM_LICK_STABLE_FLAG) == RESET)
  {
    crm_clock_source_enable(CRM_CLOCK_SOURCE_LICK, TRUE);
    while(crm_flag_get(CRM_LICK_STABLE_FLAG) == RESET);
  }
}

---------------------------------------------------------------------------------
2. at32_emac.h
#define RX_REMAP                         (0)
//#define CRYSTAL_ON_PHY                   (1)
#define CRYSTAL_ON_PHY                   (0)    // Board "AT START F407" V1.2 without crystal on Phy  --> NO Effect


---------------------------------------------------------------------------------
3. at32_emac.c  
void static reset_phy(void)
{ 
// Change drive Port Reset Pin Phy: PortB.4 --> 
// For Board "AT START F407" V1.2(0) Drive Port Reset Pin Phy --> PortC.8
// For Board SKS-52 Drive Port Reset Pin Phy --> PortC.0 

//#define PORT_RESET_PHY  GPIOB
#define PORT_RESET_PHY  GPIOC

//#define PIN_RESET_PHY  GPIO_PINS_4
//#define PIN_RESET_PHY  GPIO_PINS_8
#define PIN_RESET_PHY  GPIO_PINS_0

  gpio_init_type gpio_init_struct = {0};
  
  gpio_default_para_init(&gpio_init_struct);
  
  gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;
  gpio_init_struct.gpio_out_type = GPIO_OUTPUT_PUSH_PULL;
  gpio_init_struct.gpio_pins = PIN_RESET_PHY;    // Change drive Pin Port Reset Pin Phy
  gpio_init_struct.gpio_pull = GPIO_PULL_NONE;
  gpio_init(PORT_RESET_PHY, &gpio_init_struct);  // Change drive Port Reset Pin Phy
  
  gpio_bits_reset(PORT_RESET_PHY, PIN_RESET_PHY);
  delay_ms(2);
  gpio_bits_set(PORT_RESET_PHY, PIN_RESET_PHY);
  delay_us(2);
}
 

---------------------------------------------------------------------------------
4. Set MAC and IP    
netconf.c

static uint8_t mac_address[MAC_ADDR_LENGTH] = {0, 0, 0x44, 0x45, 0x56, 2};
#if LWIP_DHCP
volatile uint32_t dhcp_fine_timer = 0;
volatile uint32_t dhcp_coarse_timer = 0;
#else
//static uint8_t local_ip[ADDR_LENGTH]   = {192, 168, 81, 37};
//static uint8_t local_gw[ADDR_LENGTH]   = {192, 168, 81, 187};

// ping 192.168.1.37
static uint8_t local_ip[ADDR_LENGTH]   = {192, 168, 1, 37};  // 0xC0, 0xA8, 0x01, 0x25
static uint8_t local_gw[ADDR_LENGTH]   = {192, 168, 1, 187}; // 0xC0, 0xA8, 0x01, 0xBB


static uint8_t local_mask[ADDR_LENGTH] = {255, 255, 255, 0};
#endif


---------------------------------------------------------------------------------
5. Project for SKS-31
- ���������� ��� ����. ������������� *_board.* --> SKS_31_board.*
- ���������� ����� ������ ����������.
������ ����� {192, 168, 1, 37}