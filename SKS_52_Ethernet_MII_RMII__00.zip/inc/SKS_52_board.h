/**
  **************************************************************************
  * @file     at32f403a_407_board.h
  * @brief    header file for at-start board. set of firmware functions to
  *           manage leds and push-button. initialize delay function.
  **************************************************************************
*/

#ifndef __AT32F403A_407_BOARD_H
#define __AT32F403A_407_BOARD_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdio.h"
#include "at32f403a_407.h"

/* this header include define support list:
  * 1. SKS-52 RMII board
  * 2. SKS-52 MII  board
  * if define AT_START_F403A_V1, the header file support at-start-f403a v1.x board
  * if define AT_START_F407_V1, the header file support at-start-f407 v1.x board
*/

#if !defined (AT_START_F403A_V1)&& !defined (AT_START_F407_V1)
#error "please select first the board at-start device used in your application (in at32f403a_407_board.h file)"
#endif

/******************** define led ********************/
typedef enum
{
  LD0                                   = 0,
  LD1                                   = 1,
  LD2                                   = 2,
} led_type;

#define LED_NUM                          3

#define LD0_PIN                         GPIO_PINS_8
#define LD0_GPIO                        GPIOB
#define LD0_GPIO_CRM_CLK                CRM_GPIOB_PERIPH_CLOCK

#define LD1_PIN                         GPIO_PINS_9
#define LD1_GPIO                        GPIOB
#define LD1_GPIO_CRM_CLK                CRM_GPIOB_PERIPH_CLOCK

#define LD2_PIN                         GPIO_PINS_0
#define LD2_GPIO                        GPIOE
#define LD2_GPIO_CRM_CLK                CRM_GPIOE_PERIPH_CLOCK


// **************** define print uart ******************
#define PRINT_UART                       USART1
#define PRINT_UART_CRM_CLK               CRM_USART1_PERIPH_CLOCK
#define PRINT_UART_TX_PIN                GPIO_PINS_9
#define PRINT_UART_TX_GPIO               GPIOA
#define PRINT_UART_TX_GPIO_CRM_CLK       CRM_GPIOA_PERIPH_CLOCK

/*
// ******************* define button ******************
typedef enum
{
  USER_BUTTON                            = 0,
  NO_BUTTON                              = 1
} button_type;

#define USER_BUTTON_PIN                  GPIO_PINS_12
#define USER_BUTTON_PORT                 GPIOA
#define USER_BUTTON_CRM_CLK              CRM_GPIOA_PERIPH_CLOCK
*/


typedef enum
{
  AddrPortEth_0                            = 0,
  AddrPortEth_1                            = 1,
  AddrPortEth_2                            = 2,
  AddrPortEth_3                            = 3,
} AddrPortEth_type;

#define AddrPortEth_0                      GPIO_PINS_3    // RE3
#define AddrPortEth_0_GPIO                 GPIOE
#define AddrPortEth_0_GPIO_CRM_CLK         CRM_GPIOE_PERIPH_CLOCK

#define AddrPortEth_1                      GPIO_PINS_15   // PC15
#define AddrPortEth_1_GPIO                 GPIOC
#define AddrPortEth_1_GPIO_CRM_CLK         CRM_GPIOC_PERIPH_CLOCK

#define AddrPortEth_2                      GPIO_PINS_14   // PC14
#define AddrPortEth_2_GPIO                 GPIOC
#define AddrPortEth_2_GPIO_CRM_CLK         CRM_GPIOC_PERIPH_CLOCK

#define AddrPortEth_3                      GPIO_PINS_13   // PC13
#define AddrPortEth_3_GPIO                 GPIOC
#define AddrPortEth_3_GPIO_CRM_CLK         CRM_GPIOC_PERIPH_CLOCK




/** @defgroup BOARD_exported_functions
  * @{
  */

/******************** functions ********************/
void at32_board_init(void);

// led operation function 
void at32_led_init(led_type led);
void at32_led_on(led_type led);
void at32_led_off(led_type led);
void at32_led_toggle(led_type led);

/*
// button operation function 
void at32_button_init(void);
button_type at32_button_press(void);
uint8_t at32_button_state(void);
*/

// delay function 
void delay_init(void);
void delay_us(uint32_t nus);
void delay_ms(uint16_t nms);
void delay_sec(uint16_t sec);

// printf uart init function 
void uart_print_init(uint32_t baudrate);

// AddrPortEth ini 
uint8_t AddrPortEth_init(void);


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif

