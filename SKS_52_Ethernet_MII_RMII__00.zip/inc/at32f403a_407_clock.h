/**
  **************************************************************************
  * @file     at32f403a_407_clock.h
  * @version  v2.0.0
  * @date     2020-11-02
  * @brief    header file of clock program
  **************************************************************************
*/

/* define to prevent recursive inclusion -------------------------------------*/
#ifndef __AT32F403A_407_CLOCK_H
#define __AT32F403A_407_CLOCK_H

#ifdef __cplusplus
extern "C" {
#endif

/* includes ------------------------------------------------------------------*/
#include "at32f403a_407.h"

/* exported functions ------------------------------------------------------- */
void system_clock_config(void);

#ifdef __cplusplus
}
#endif

#endif /* __AT32F403A_407_CLOCK_H */

