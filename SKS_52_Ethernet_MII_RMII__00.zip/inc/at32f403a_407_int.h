/**
  **************************************************************************
  * @file     at32f403a_407_int.h
  * @version  v2.0.0
  * @date     2020-11-02
  * @brief    header file of main interrupt service routines.
  **************************************************************************
*/

/* define to prevent recursive inclusion -------------------------------------*/
#ifndef __AT32F403A_407_INT_H
#define __AT32F403A_407_INT_H

#ifdef __cplusplus
extern "C" {
#endif

/* includes ------------------------------------------------------------------*/
#include "at32f403a_407.h"

/* exported types ------------------------------------------------------------*/
/* exported constants --------------------------------------------------------*/
/* exported macro ------------------------------------------------------------*/
/* exported functions ------------------------------------------------------- */

void NMI_Handler(void);
void HardFault_Handler(void);
void MemManage_Handler(void);
void BusFault_Handler(void);
void UsageFault_Handler(void);
void SVC_Handler(void);
void DebugMon_Handler(void);
void PendSV_Handler(void);
void SysTick_Handler(void);

#ifdef __cplusplus
}
#endif

#endif

